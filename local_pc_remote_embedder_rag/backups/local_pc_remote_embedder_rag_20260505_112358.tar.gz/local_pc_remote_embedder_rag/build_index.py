import argparse
import uuid

from config import ProjectConfig
from data_loader import load_idiom_rows
from embedder_api import embed_texts
from qdrant_api import QdrantHttpClient


def ensure_collection(client: QdrantHttpClient, collection_name: str, vector_size: int) -> None:
    collections = client.list_collections()
    if collection_name in collections:
        return

    client.create_collection(collection_name=collection_name, vector_size=vector_size)


def build_index(config: ProjectConfig, recreate_collection: bool = False, direction: str = "en_to_sl") -> dict:
    idiom_rows = load_idiom_rows(config.data_roots(), direction=direction)

    # Adjust text labels based on direction
    if direction == "sl_to_en":
        source_label = "slovene_idiom"
        target_label = "english_translation"
    else:
        source_label = "english_idiom"
        target_label = "slovene_translation"

    idiom_texts = []
    for row in idiom_rows:
        searchable_text = "\n".join(
            [
                f"{source_label}: {row.get('idiom', '')}",
                f"meaning: {row.get('meaning', '')}",
                f"{target_label}: {row.get('target_translation', '')}",
            ]
        ).strip()
        idiom_texts.append(searchable_text)

    vectors: list[list[float]] = []
    fallback_count = 0
    for index, row in enumerate(idiom_rows):
        primary_text = idiom_texts[index]
        idiom_only_text = str(row.get("idiom", "")).strip()

        try:
            vector = embed_texts([primary_text], config)[0]
            vectors.append(vector)
            continue
        except Exception as primary_error:
            if not idiom_only_text:
                raise RuntimeError(
                    f"Embedding failed for row {index} and no idiom fallback exists."
                ) from primary_error

            try:
                vector = embed_texts([idiom_only_text], config)[0]
                vectors.append(vector)
                fallback_count += 1
            except Exception as fallback_error:
                raise RuntimeError(
                    f"Embedding failed for row {index} idiom='{idiom_only_text}'. "
                    f"Primary error: {primary_error}; Fallback error: {fallback_error}"
                ) from fallback_error

    if not vectors:
        raise RuntimeError("No vectors generated.")

    client = QdrantHttpClient(url=config.qdrant_url, api_key=config.qdrant_api_key, timeout=30)
    if recreate_collection:
        collections = client.list_collections()
        if config.qdrant_collection in collections:
            client.delete_collection(collection_name=config.qdrant_collection)

    ensure_collection(client, config.qdrant_collection, vector_size=len(vectors[0]))

    points = []
    for index, row in enumerate(idiom_rows):
        stable_key = f"{row['idiom_norm']}|{row['source_file']}"
        points.append(
            {
                "id": str(uuid.uuid5(uuid.NAMESPACE_URL, stable_key)),
                "vector": vectors[index],
                "payload": {
                    "idiom": row["idiom"],
                    "idiom_norm": row["idiom_norm"],
                    "meaning": row["meaning"],
                    "target_translation": row["target_translation"],
                    "searchable_text": idiom_texts[index],
                    "source_file": row["source_file"],
                },
            }
        )

    client.upsert_points(collection_name=config.qdrant_collection, points=points, wait=True)
    return {
        "indexed_rows": len(points),
        "collection": config.qdrant_collection,
        "fallback_embed_count": fallback_count,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Build Qdrant index")
    parser.add_argument("--recreate-collection", action="store_true", help="Drop existing collection first")
    parser.add_argument("--direction", choices=["en_to_sl", "sl_to_en"], default="en_to_sl", help="Translation direction")
    args = parser.parse_args()

    config = ProjectConfig()
    result = build_index(config, recreate_collection=args.recreate_collection, direction=args.direction)
    print(result)


if __name__ == "__main__":
    main()
